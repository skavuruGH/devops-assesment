# string-parse
Perl script to print longest word in a sentence and its length and shortest word in a sentence and its length
print_min_max_strings.pl
   
   print_min_max_strings.pl is a perl script to print longest word in a sentence and its length and shortest word in a sentence and its length

Compilation: 
    perl -c print_min_max_strings.pl
Usage
    perl print_min_max_strings.pl The cow jumped over the moon

Assumptions : Should Pass the string as an input at the command line 

Unit Test : 
           Input: 
           The cow jumped over the moon
           Output: 
Input string : The cow jumped over the moon

Max string Length: 6 - jumped
Min string Length: 3 - the
